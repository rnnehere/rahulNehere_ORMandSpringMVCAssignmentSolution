create database customerdb;
use customerdb;
create table customer
(
id int primary key auto_increment,
first_name varchar(40),
 last_name varchar(40),
email varchar(40)
 );
  
insert into customer(first_name,last_name,email) values ('Rahul','Nehere','email');